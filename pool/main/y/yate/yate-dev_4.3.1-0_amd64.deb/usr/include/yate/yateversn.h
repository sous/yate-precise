/*
 * yateversn.h
 * This file is part of the YATE Project http://YATE.null.ro
 *
 * This is a generated file. You should never need to modify it.
 * Take a look at the source file yateversn.h.in instead.
 */

#ifndef __YATEVERSN_H
#define __YATEVERSN_H

/* Version numbers */
#define YATE_MAJOR 4
#define YATE_MINOR 3
#define YATE_BUILD 0

/* Version strings */
#define YATE_MAJOR_S "4"
#define YATE_MINOR_S "3"
#define YATE_BUILD_S "0"
#define YATE_VERSION "4.3.0"
#define YATE_RELEASE "1"
#define YATE_STATUS  ""

/* Windows version resource - file and string style */
#define YATE_WINVER_F 4,3,0,1
#define YATE_WINVER_S "4, 3, 0, 1\0"

#endif /* __YATEVERSN_H */
